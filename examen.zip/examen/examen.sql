CREATE DATABASE usuario;
USE usuario;

CREATE TABLE Usuario (
    Nombre VARCHAR(50) NOT NULL,
    Contraseña VARCHAR(50) NOT NULL,
    PRIMARY KEY (Nombre)
    )